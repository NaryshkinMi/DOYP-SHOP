const CATALOG = [
    {
        id: 'el1',
        name: 'Товар 1',
        img: 'https://cdn-icons-png.flaticon.com/512/3639/3639180.png',
        price: 3200
    },
    {
        id: 'el2',
        name: 'Товар 2',
        img: 'https://cdn-icons-png.flaticon.com/512/3639/3639180.png',
        price: 7500
    },
    {
        id: 'el3',
        name: 'Товар 3',
        img: 'https://cdn-icons-png.flaticon.com/512/3639/3639180.png',
        price: 12500
    },
    {
        id: 'el4',
        name: 'Товар 4',
        img: 'https://cdn-icons-png.flaticon.com/512/3639/3639180.png',
        price: 256799
    },
    {
        id: 'el5',
        name: 'Товар 5',
        img: 'https://cdn-icons-png.flaticon.com/512/3639/3639180.png',
        price: 1999
    },
    {
        id: 'el6',
        name: 'Товар 6',
        img: 'https://cdn-icons-png.flaticon.com/512/3639/3639180.png',
        price: 2999
    },
    {
        id: 'el7',
        name: 'Товар 7',
        img: 'https://cdn-icons-png.flaticon.com/512/3639/3639180.png',
        price: 5999
    },
    {
        id: 'el8',
        name: 'Товар 8',
        img: 'https://cdn-icons-png.flaticon.com/512/3639/3639180.png',
        price: 49999
    },
    {
        id: 'el9',
        name: 'Товар 9',
        img: 'https://cdn-icons-png.flaticon.com/512/3639/3639180.png',
        price: 49999
    },
    {
        id: 'el10',
        name: 'Товар 10',
        img: 'https://cdn-icons-png.flaticon.com/512/3639/3639180.png',
        price: 49999
    }
];