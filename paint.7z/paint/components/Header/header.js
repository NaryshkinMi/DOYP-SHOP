class Header {
  heanlkeOpenStorePage() {
    shoppingPage.render();
  }

  render(count) {
    const html = `
        <div class="header-container">
            <div class="header-counter">
             DOYP SHOP
            </div>
            <div class="header__name" onclick="headerPage.heanlkeOpenStorePage();">
              💰 ${count}
            </div>

        </div>
    `;

    ROOT_HEADER.innerHTML = html;
  }
}

const headerPage = new Header();
const productsStore = localStorageUtil.getProducts();

headerPage.render(productsStore.length);
