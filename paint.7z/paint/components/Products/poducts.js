class Products {
  constructor() {
    this.activeClas = "products-elements__btn_active";
    this.lableAdd = "Добавить в корзину";
    this.lableDel = "Удалить из корзины";
  }

  handleLocationStorage(element, id) {
    const { pushProduct, products } = localStorageUtil.putProducts(id);

    if (pushProduct) {
      element.classList.add(this.activeClas);
      element.innerHTML = this.lableDel;
    } else {
      element.classList.remove(this.activeClas);
      element.innerHTML = this.lableAdd;
    }
    headerPage.render(products.length);
  }

  render() {
    let htmlCatalog = "";
    const productsStore = localStorageUtil.getProducts();
    CATALOG.forEach(({ id, name, price, img }) => {
      let activeClass = "";
      let activeText = "";

      if (productsStore.indexOf(id) === -1) {
        activeText = this.lableAdd;
      } else {
        activeClass = " " + this.activeClas;
        activeText = this.lableDel;
      }

      htmlCatalog += `
            <li class="products-elements">
                <span class="products-elements__name">${name}</span>
                <img class="products-elements__img" src = "${img}" />
                <span class="products-elements__price">price: ${price.toLocaleString()} USD</span>
                <button class="products-elements__btn ${activeClass}" onclick="productsPage.handleLocationStorage(this, '${id}');">
                  ${activeText}
                </button>
            </li>
        `;
    });

    const html = `
        <ul class="products-contaiber">
            ${htmlCatalog}
        </ul>
    `;
    ROOT_PRODUCTS.innerHTML = html;
  }
}

const productsPage = new Products();
productsPage.render();
